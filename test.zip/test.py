get = count = 0
sum = avg = 0
num = []

def isNum(input) :
    try:
        float(input)
        return 1
    except ValueError:
        return 0

def average(list) :
    global sum
    for i in list :
        sum += i
    return sum / count

def findEdge(list, flag) :
    value = list[0]
    if flag :
        for i in list :
            if (value < i) :
                value = i
        # return max(list)
    else :
        for i in list :
            if(value > i) :
                value = i
        # return min(list)
    return value

while(get != 'q') :
    get = input("숫자를 입력해 주세요 : ")
    if(isNum(get)) :
        num.append(int(get))
        count += 1
    else :
        if(get == 'q') :
            break

avg = average(num)

print("\n입력건수 : ", count)
print("총합 : ", sum)
print("평균 : ", avg)
print("최소값 : ", findEdge(num, 0))
print("최대값 : ", findEdge(num, 1))
